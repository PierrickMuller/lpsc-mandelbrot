# lpsc-mandelbrot

Projet Mandelbrot pour le cours LPSC